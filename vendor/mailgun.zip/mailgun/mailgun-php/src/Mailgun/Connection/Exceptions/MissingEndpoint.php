<?php
namespace Mailgun\Connection\Exceptions;

class MissingEndpoint extends \Exception{}
