<?php
namespace Mailgun\Messages\Exceptions;

class InvalidParameterType extends \Exception{}
